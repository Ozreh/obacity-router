"""Граница города: полигон и проверки «точка внутри»."""
import json
from pathlib import Path
from typing import Sequence

import shapely
from shapely.geometry import Point, Polygon


class Boundary:
    def __init__(self, ring: Sequence[Sequence[float]]):
        # ring хранится как [[lat, lon], ...] (формат Leaflet),
        # а shapely работает с (x=lon, y=lat)
        self.ring = [list(p) for p in ring]
        self._polygon = Polygon([(lon, lat) for lat, lon in self.ring])
        shapely.prepare(self._polygon)  # ускоряет повторные проверки

    @classmethod
    def from_file(cls, path: Path) -> "Boundary":
        with open(path, encoding="utf-8") as f:
            return cls(json.load(f)["ring"])

    def contains(self, lat: float, lon: float) -> bool:
        return self._polygon.contains(Point(lon, lat))

    def contains_many(self, lats, lons):
        """Векторная проверка для большого числа точек (маска True/False)."""
        return shapely.contains_xy(self._polygon, lons, lats)