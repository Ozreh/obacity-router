"""Построение пешеходного графа из .osm и его кэширование.

osmnx нужен только при сборке графа, поэтому импортируется лениво:
при старте с готовым кэшем тяжёлая библиотека вообще не загружается.
"""
import logging
import pickle

import networkx as nx

from .boundary import Boundary
from .config import Settings

log = logging.getLogger(__name__)


def _is_walkable(data: dict, bad_highways: frozenset) -> bool:
    """Оставляем только рёбра-дороги, подходящие для пешехода."""
    hw = data.get("highway")
    if hw is None:  # здания, ж/д, границы и прочее — не дороги
        return False
    hw = hw if isinstance(hw, list) else [hw]
    if all(h in bad_highways for h in hw):
        return False
    if data.get("foot") == "no" or data.get("access") in ("no", "private"):
        return False
    return True


def build_walk_graph(settings: Settings, boundary: Boundary) -> nx.Graph:
    """Читает .osm и возвращает компактный неориентированный граф.

    Узлы: атрибуты y (lat), x (lon). Рёбра: length в метрах.
    """
    import osmnx as ox

    log.info("Строим граф из %s (это долго, но один раз)...", settings.osm_file.name)
    # bidirectional=True: пешеходу не важны односторонние улицы
    # simplify=False: сначала фильтруем, так сохраняется точная форма дорог
    g = ox.graph_from_xml(settings.osm_file, bidirectional=True, simplify=False, retain_all=True)

    # Убираем всё, что не дорога (в .osm десятки тысяч зданий)
    bad = [
        (u, v, k)
        for u, v, k, d in g.edges(keys=True, data=True)
        if not _is_walkable(d, settings.bad_highways)
    ]
    g.remove_edges_from(bad)
    g.remove_nodes_from(list(nx.isolates(g)))

    # Обрезаем по границе: узлы снаружи уходят вместе со своими рёбрами
    ids = list(g.nodes)
    mask = boundary.contains_many(
        [g.nodes[n]["y"] for n in ids], [g.nodes[n]["x"] for n in ids]
    )
    g.remove_nodes_from([n for n, ok in zip(ids, mask) if not ok])
    g.remove_nodes_from(list(nx.isolates(g)))

    # Сжимаем MultiDiGraph в простой Graph: один минимальный по длине отрезок
    # на пару узлов. Он меньше и быстрее считается.
    compact = nx.Graph()
    for n, d in g.nodes(data=True):
        compact.add_node(n, y=d["y"], x=d["x"])
    for u, v, d in g.edges(data=True):
        if u == v:
            continue
        length = d["length"]
        if compact.has_edge(u, v) and compact[u][v]["length"] <= length:
            continue
        compact.add_edge(u, v, length=length)

    # Самая большая связная часть, иначе точки попадают на «острова»
    biggest = max(nx.connected_components(compact), key=len)
    return compact.subgraph(biggest).copy()


def load_walk_graph(settings: Settings, boundary: Boundary) -> nx.Graph:
    """Берёт граф из кэша, если он свежий, иначе строит заново и сохраняет."""
    newest_source = max(
        settings.osm_file.stat().st_mtime, settings.boundary_file.stat().st_mtime
    )
    cache = settings.cache_file
    if cache.exists() and cache.stat().st_mtime > newest_source:
        try:
            with open(cache, "rb") as f:
                version, graph = pickle.load(f)
            if version == settings.cache_version:
                log.info("Граф загружен из кэша")
                return graph
        except Exception:
            log.warning("Кэш повреждён, пересобираем граф")

    graph = build_walk_graph(settings, boundary)
    with open(cache, "wb") as f:
        pickle.dump((settings.cache_version, graph), f, protocol=pickle.HIGHEST_PROTOCOL)
    return graph