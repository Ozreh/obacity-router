"""Все настройки в одном месте: пути к данным и параметры графа."""
from dataclasses import dataclass
from pathlib import Path

# Корень бэкенда (папка, где лежит main.py). От неё считаем все пути,
# поэтому uvicorn можно запускать из любой директории.
BASE_DIR = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    osm_file: Path = BASE_DIR / "extracted.osm"
    boundary_file: Path = BASE_DIR / "obama_boundary.json"
    cache_file: Path = BASE_DIR / "graph_walk.pickle"  # готовый граф, чтобы не парсить 80 МБ при старте

    # Дороги, по которым пешком не ходят
    bad_highways: frozenset = frozenset(
        {"motorway", "motorway_link", "construction", "proposed", "raceway", "bus_guideway"}
    )

    # Меняй при правке логики построения графа, чтобы старый кэш пересобрался
    cache_version: int = 1


settings = Settings()