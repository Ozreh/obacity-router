"""Сервис маршрутов: привязка точки к графу и поиск кратчайшего пути."""
import math

import networkx as nx
import numpy as np
from sklearn.neighbors import BallTree

from .boundary import Boundary

EARTH_RADIUS_M = 6_371_000.0  # чуть меньше радиуса osmnx, чтобы эвристика была допустимой


class RouteError(Exception):
    """Базовая ошибка построения маршрута (текст показывается пользователю)."""


class OutsideBoundaryError(RouteError):
    pass


class NoPathError(RouteError):
    pass


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (
        math.sin((p2 - p1) / 2) ** 2
        + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2
    )
    return 2 * EARTH_RADIUS_M * math.asin(math.sqrt(a))


class RoutingService:
    def __init__(self, graph: nx.Graph, boundary: Boundary):
        self.graph = graph
        self.boundary = boundary
        # Индекс ближайших узлов строим ОДИН раз при старте.
        # (nearest_nodes из osmnx перестраивает его на каждый запрос.)
        self._ids = list(graph.nodes)
        coords = np.radians([[graph.nodes[n]["y"], graph.nodes[n]["x"]] for n in self._ids])
        self._tree = BallTree(coords, metric="haversine")

    def nearest_node(self, lat: float, lon: float):
        _, idx = self._tree.query(np.radians([[lat, lon]]), k=1)
        return self._ids[int(idx[0][0])]

    def _heuristic(self, target):
        t = self.graph.nodes[target]

        def h(u, _v):
            n = self.graph.nodes[u]
            return haversine_m(n["y"], n["x"], t["y"], t["x"])

        return h

    def route(self, lat1: float, lon1: float, lat2: float, lon2: float) -> list[list[float]]:
        """Возвращает [[lat, lon], ...] или бросает RouteError."""
        if not (self.boundary.contains(lat1, lon1) and self.boundary.contains(lat2, lon2)):
            raise OutsideBoundaryError("Точка за пределами Обамы")

        start = self.nearest_node(lat1, lon1)
        goal = self.nearest_node(lat2, lon2)
        try:
            # A* с прямой по земле как эвристикой: быстрее Дейкстры, результат тот же
            nodes = nx.astar_path(
                self.graph, start, goal, heuristic=self._heuristic(goal), weight="length"
            )
        except nx.NetworkXNoPath:
            raise NoPathError("Между точками нет пешего пути")

        return [[self.graph.nodes[n]["y"], self.graph.nodes[n]["x"]] for n in nodes]