"""Сборка приложения: загрузка данных при старте и подключение роутов."""
import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import router
from .boundary import Boundary
from .config import settings
from .graph_builder import load_walk_graph
from .routing import RoutingService

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger(__name__)


def load_service() -> RoutingService:
    boundary = Boundary.from_file(settings.boundary_file)
    graph = load_walk_graph(settings, boundary)
    log.info("Граф готов: %d узлов, %d рёбер", graph.number_of_nodes(), graph.number_of_edges())
    return RoutingService(graph, boundary)


def create_app(service: Optional[RoutingService] = None) -> FastAPI:
    """service можно подставить снаружи (так делают тесты, без чтения .osm)."""

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if getattr(app.state, "service", None) is None:
            app.state.service = load_service()
        yield

    app = FastAPI(title="Пешеходный навигатор: Обама", lifespan=lifespan)
    app.state.service = service
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(router)
    return app