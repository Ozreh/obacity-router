import hashlib
import hmac
import json
import logging
import math
import os
import pickle
import re
import secrets
import sqlite3
import time
from contextlib import asynccontextmanager, closing
from pathlib import Path
from typing import Optional

import jwt
import networkx as nx
import numpy as np
import shapely
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from shapely.geometry import Point, Polygon
from sklearn.neighbors import BallTree

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger("navigator")


BASE_DIR = Path(__file__).resolve().parent
OSM_FILE = BASE_DIR / "extracted.osm"
BOUNDARY_FILE = BASE_DIR / "obama_boundary.json"
CACHE_FILE = BASE_DIR / "graph_walk.pickle"
CACHE_VERSION = 1


BAD_HIGHWAYS = {"motorway", "motorway_link", "construction", "proposed", "raceway", "bus_guideway"}

EARTH_RADIUS_M = 6_371_000.0

DB_FILE = BASE_DIR / "users.db"
SECRET_FILE = BASE_DIR / ".auth_secret"
GOOGLE_ID_FILE = BASE_DIR / "google_client_id.txt"
FRONTEND_DIR = BASE_DIR.parent / "frontend"
TOKEN_TTL_SECONDS = 7 * 24 * 3600
PASSWORD_MIN_LEN = 8
PASSWORD_MAX_LEN = 128
NAME_MAX_LEN = 60
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 14, 8, 1
LOGIN_MAX_FAILS = 5
LOGIN_WINDOW_S = 300
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


with open(BOUNDARY_FILE, encoding="utf-8") as f:
    RING = json.load(f)["ring"]
BOUNDARY = Polygon([(lon, lat) for lat, lon in RING])
shapely.prepare(BOUNDARY)


def is_walkable(data: dict) -> bool:
    hw = data.get("highway")
    if hw is None:
        return False
    hw = hw if isinstance(hw, list) else [hw]
    if all(h in BAD_HIGHWAYS for h in hw):
        return False
    if data.get("foot") == "no" or data.get("access") in ("no", "private"):
        return False
    return True


def build_walk_graph() -> nx.Graph:
    import osmnx as ox

    log.info("Строим граф из %s (долго, но один раз)...", OSM_FILE.name)


    g = ox.graph_from_xml(OSM_FILE, bidirectional=True, simplify=False, retain_all=True)


    bad = [(u, v, k) for u, v, k, d in g.edges(keys=True, data=True) if not is_walkable(d)]
    g.remove_edges_from(bad)
    g.remove_nodes_from(list(nx.isolates(g)))


    ids = list(g.nodes)
    mask = shapely.contains_xy(
        BOUNDARY, [g.nodes[n]["x"] for n in ids], [g.nodes[n]["y"] for n in ids]
    )
    g.remove_nodes_from([n for n, ok in zip(ids, mask) if not ok])
    g.remove_nodes_from(list(nx.isolates(g)))


    compact = nx.Graph()
    for n, d in g.nodes(data=True):
        compact.add_node(n, y=d["y"], x=d["x"])
    for u, v, d in g.edges(data=True):
        if u == v:
            continue
        if compact.has_edge(u, v) and compact[u][v]["length"] <= d["length"]:
            continue
        compact.add_edge(u, v, length=d["length"])


    biggest = max(nx.connected_components(compact), key=len)
    return compact.subgraph(biggest).copy()


def load_walk_graph() -> nx.Graph:
    newest_source = max(OSM_FILE.stat().st_mtime, BOUNDARY_FILE.stat().st_mtime)
    if CACHE_FILE.exists() and CACHE_FILE.stat().st_mtime > newest_source:
        try:
            with open(CACHE_FILE, "rb") as f:
                version, graph = pickle.load(f)
            if version == CACHE_VERSION:
                log.info("Граф загружен из кэша")
                return graph
        except Exception:
            log.warning("Кэш повреждён, пересобираем граф")

    graph = build_walk_graph()
    with open(CACHE_FILE, "wb") as f:
        pickle.dump((CACHE_VERSION, graph), f, protocol=pickle.HIGHEST_PROTOCOL)
    return graph


class RouteError(Exception):
    pass


def haversine_m(lat1, lon1, lat2, lon2) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (
        math.sin((p2 - p1) / 2) ** 2
        + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2
    )
    return 2 * EARTH_RADIUS_M * math.asin(math.sqrt(a))


class RoutingService:
    def __init__(self, graph: nx.Graph):
        self.graph = graph


        self._ids = list(graph.nodes)
        coords = np.radians([[graph.nodes[n]["y"], graph.nodes[n]["x"]] for n in self._ids])
        self._tree = BallTree(coords, metric="haversine")

    def nearest_node(self, lat: float, lon: float):
        _, idx = self._tree.query(np.radians([[lat, lon]]), k=1)
        return self._ids[int(idx[0][0])]

    def route(self, lat1, lon1, lat2, lon2) -> list[list[float]]:
        if not (BOUNDARY.contains(Point(lon1, lat1)) and BOUNDARY.contains(Point(lon2, lat2))):
            raise RouteError("Точка за пределами Обамы")

        start = self.nearest_node(lat1, lon1)
        goal = self.nearest_node(lat2, lon2)
        t = self.graph.nodes[goal]

        def heuristic(u, _v):
            n = self.graph.nodes[u]
            return haversine_m(n["y"], n["x"], t["y"], t["x"])

        try:
            nodes = nx.astar_path(self.graph, start, goal, heuristic=heuristic, weight="length")
        except nx.NetworkXNoPath:
            raise RouteError("Между точками нет пешего пути")
        return [[self.graph.nodes[n]["y"], self.graph.nodes[n]["x"]] for n in nodes]


def load_google_client_id() -> str:
    value = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
    if not value and GOOGLE_ID_FILE.exists():
        value = GOOGLE_ID_FILE.read_text(encoding="utf-8").strip()
    return value


def load_jwt_secret() -> str:
    value = os.environ.get("AUTH_SECRET", "").strip()
    if value:
        return value
    if SECRET_FILE.exists():
        return SECRET_FILE.read_text(encoding="utf-8").strip()
    value = secrets.token_hex(32)
    SECRET_FILE.write_text(value, encoding="utf-8")
    return value


GOOGLE_CLIENT_ID = load_google_client_id()
JWT_SECRET = load_jwt_secret()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with closing(db()) as conn, conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS users ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "email TEXT NOT NULL UNIQUE, "
            "name TEXT NOT NULL, "
            "password_hash TEXT, "
            "google_sub TEXT UNIQUE, "
            "created_at INTEGER NOT NULL)"
        )


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32
    )
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, n, r, p, salt, digest = stored.split("$")
        expected = bytes.fromhex(digest)
        actual = hashlib.scrypt(
            password.encode(), salt=bytes.fromhex(salt), n=int(n), r=int(r), p=int(p), dklen=len(expected)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


DUMMY_HASH = hash_password("dummy-password-for-timing")

login_failures: dict = {}


def rate_limit_key(request: Request, email: str) -> str:
    ip = request.client.host if request.client else "unknown"
    return f"{ip}|{email}"


def check_rate_limit(key: str):
    now = time.time()
    recent = [t for t in login_failures.get(key, []) if now - t < LOGIN_WINDOW_S]
    if recent:
        login_failures[key] = recent
    else:
        login_failures.pop(key, None)
    if len(recent) >= LOGIN_MAX_FAILS:
        raise HTTPException(429, "Слишком много попыток входа. Подождите несколько минут")


def register_failure(key: str):
    login_failures.setdefault(key, []).append(time.time())


def issue_token(user_id: int) -> str:
    now = int(time.time())
    payload = {"sub": str(user_id), "iat": now, "exp": now + TOKEN_TTL_SECONDS}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def public_user(row) -> dict:
    return {"id": row["id"], "email": row["email"], "name": row["name"]}


def auth_response(row) -> dict:
    return {"token": issue_token(row["id"]), "user": public_user(row)}


def normalize_email(value: str) -> str:
    email = (value or "").strip().lower()
    if len(email) > 254 or not EMAIL_RE.match(email):
        raise HTTPException(400, "Введите корректный email")
    return email


def clean_name(value: str, email: str) -> str:
    name = (value or "").strip()[:NAME_MAX_LEN]
    return name or email.split("@")[0]


bearer = HTTPBearer(auto_error=False)


def current_user(creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> dict:
    if creds is None:
        raise HTTPException(401, "Требуется вход")
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=["HS256"])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(401, "Сессия истекла, войдите снова")
    with closing(db()) as conn:
        row = conn.execute("SELECT id, email, name FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(401, "Сессия истекла, войдите снова")
    return public_user(row)


def verify_google_token(credential: str) -> dict:
    from google.auth.transport import requests as google_requests
    from google.oauth2 import id_token

    return id_token.verify_oauth2_token(credential, google_requests.Request(), GOOGLE_CLIENT_ID)


class RegisterBody(BaseModel):
    email: str
    password: str
    name: str = ""


class LoginBody(BaseModel):
    email: str
    password: str


class GoogleBody(BaseModel):
    credential: str


service: Optional[RoutingService] = None


@asynccontextmanager
async def lifespan(_app: FastAPI):
    global service
    init_db()
    graph = load_walk_graph()
    log.info("Граф готов: %d узлов, %d рёбер", graph.number_of_nodes(), graph.number_of_edges())
    service = RoutingService(graph)
    yield


app = FastAPI(title="Пешеходный навигатор: Обама", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/route")
def calculate_route(
    lat1: float, lon1: float, lat2: float, lon2: float, _user: dict = Depends(current_user)
):
    try:
        return {"route": service.route(lat1, lon1, lat2, lon2)}
    except RouteError as e:
        return {"error": str(e)}
    except Exception:
        log.exception("Неожиданная ошибка построения маршрута")
        return {"error": "Маршрут не найден"}


@app.get("/boundary")
def get_boundary(_user: dict = Depends(current_user)):
    return {"name": "Obama", "ring": RING}


@app.get("/auth/config")
def auth_config():
    return {"google_client_id": GOOGLE_CLIENT_ID or None}


@app.post("/auth/register")
def register(body: RegisterBody):
    email = normalize_email(body.email)
    if not (PASSWORD_MIN_LEN <= len(body.password) <= PASSWORD_MAX_LEN):
        raise HTTPException(400, f"Пароль должен быть от {PASSWORD_MIN_LEN} до {PASSWORD_MAX_LEN} символов")
    name = clean_name(body.name, email)
    password_hash = hash_password(body.password)
    try:
        with closing(db()) as conn, conn:
            cur = conn.execute(
                "INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (email, name, password_hash, int(time.time())),
            )
            row = conn.execute("SELECT id, email, name FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Этот email уже зарегистрирован")
    return auth_response(row)


@app.post("/auth/login")
def login(body: LoginBody, request: Request):
    email = (body.email or "").strip().lower()
    key = rate_limit_key(request, email)
    check_rate_limit(key)
    with closing(db()) as conn:
        row = conn.execute(
            "SELECT id, email, name, password_hash FROM users WHERE email = ?", (email,)
        ).fetchone()
    has_password = row is not None and row["password_hash"] is not None
    stored = row["password_hash"] if has_password else DUMMY_HASH
    password_ok = verify_password(body.password[:PASSWORD_MAX_LEN], stored)
    if not (has_password and password_ok):
        register_failure(key)
        raise HTTPException(401, "Неверный email или пароль")
    login_failures.pop(key, None)
    return auth_response(row)


@app.post("/auth/google")
def google_login(body: GoogleBody):
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(503, "Вход через Google не настроен")
    try:
        info = verify_google_token(body.credential)
    except Exception:
        raise HTTPException(401, "Не удалось подтвердить вход через Google")
    email = (info.get("email") or "").strip().lower()
    sub = info.get("sub")
    if not email or not sub or not info.get("email_verified"):
        raise HTTPException(401, "Google не подтвердил email")
    with closing(db()) as conn, conn:
        row = conn.execute("SELECT id, email, name FROM users WHERE google_sub = ?", (sub,)).fetchone()
        if row is None:
            row = conn.execute("SELECT id, email, name FROM users WHERE email = ?", (email,)).fetchone()
            if row is not None:
                conn.execute("UPDATE users SET google_sub = ? WHERE id = ?", (sub, row["id"]))
        if row is None:
            name = clean_name(info.get("name", ""), email)
            cur = conn.execute(
                "INSERT INTO users (email, name, google_sub, created_at) VALUES (?, ?, ?, ?)",
                (email, name, sub, int(time.time())),
            )
            row = conn.execute("SELECT id, email, name FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    return auth_response(row)


@app.get("/auth/me")
def me(user: dict = Depends(current_user)):
    return user


if FRONTEND_DIR.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")