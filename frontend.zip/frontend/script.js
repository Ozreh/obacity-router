const API_BASE = location.protocol.startsWith('http') && location.port === '8000'
    ? location.origin
    : 'http://127.0.0.1:8000';
const TOKEN_KEY = 'obama_nav_token';
const WALK_SPEED_KMH = 5;

const map = L.map('map', { zoomControl: false }).setView([35.494, 135.748], 14);
L.control.zoom({ position: 'bottomleft' }).addTo(map);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
}).addTo(map);

const $ = id => document.getElementById(id);
const els = {
    status: $('status'), summary: $('summary'), dist: $('dist'), time: $('time'),
    coordA: $('coordA'), coordB: $('coordB'), stepA: $('stepA'), stepB: $('stepB'),
    swap: $('swap'), fit: $('fit'), locate: $('locate'), reset: $('reset'),
    auth: $('auth'), authForm: $('authForm'), authError: $('authError'), authSubmit: $('authSubmit'),
    authName: $('authName'), authEmail: $('authEmail'), authPassword: $('authPassword'),
    nameField: $('nameField'), tabLogin: $('tabLogin'), tabRegister: $('tabRegister'),
    googleBlock: $('googleBlock'), googleBtn: $('googleBtn'),
    userbar: $('userbar'), userName: $('userName'), logout: $('logout')
};

const state = { markers: { a: null, b: null }, route: null, controller: null };
const auth = { token: null, user: null, mode: 'login', busy: false };

function readToken() {
    try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
}

function saveToken(token) {
    try {
        if (token) localStorage.setItem(TOKEN_KEY, token);
        else localStorage.removeItem(TOKEN_KEY);
    } catch (e) {}
}

async function api(path, { method = 'GET', body, signal } = {}) {
    const headers = {};
    if (body) headers['Content-Type'] = 'application/json';
    if (auth.token) headers.Authorization = `Bearer ${auth.token}`;
    const res = await fetch(`${API_BASE}${path}`, {
        method, headers, signal, body: body ? JSON.stringify(body) : undefined
    });
    let data = null;
    try { data = await res.json(); } catch (e) {}
    return { ok: res.ok, status: res.status, data };
}

function errorText(res) {
    const detail = res.data && res.data.detail;
    return typeof detail === 'string' ? detail : 'Проверьте введённые данные';
}

function setAuthError(text) {
    els.authError.textContent = text || '';
}

function setAuthMode(mode) {
    auth.mode = mode;
    const reg = mode === 'register';
    els.tabLogin.classList.toggle('on', !reg);
    els.tabRegister.classList.toggle('on', reg);
    els.nameField.classList.toggle('hidden', !reg);
    els.authSubmit.textContent = reg ? 'Создать аккаунт' : 'Войти';
    els.authPassword.autocomplete = reg ? 'new-password' : 'current-password';
    setAuthError('');
}

function showAuth(message) {
    els.auth.classList.add('show', 'ready');
    els.userbar.classList.remove('show');
    els.authPassword.value = '';
    setAuthError(message);
}

function onLoggedIn(user) {
    auth.user = user;
    els.userName.textContent = user.name || user.email;
    els.userbar.classList.add('show');
    els.auth.classList.remove('show');
    els.auth.classList.add('ready');
    els.authPassword.value = '';
    setAuthError('');
    setTimeout(() => map.invalidateSize(), 0);
}

function logout(message) {
    auth.token = null;
    auth.user = null;
    saveToken(null);
    resetAll();
    showAuth(message);
}

function finishAuth(res) {
    if (res.ok && res.data && res.data.token) {
        auth.token = res.data.token;
        saveToken(auth.token);
        onLoggedIn(res.data.user);
    } else {
        setAuthError(errorText(res));
    }
}

async function submitAuth(e) {
    e.preventDefault();
    if (auth.busy) return;
    const email = els.authEmail.value.trim();
    const password = els.authPassword.value;
    if (!email || !password) {
        setAuthError('Введите email и пароль');
        return;
    }
    auth.busy = true;
    els.authSubmit.disabled = true;
    setAuthError('');
    try {
        const reg = auth.mode === 'register';
        const body = reg ? { email, password, name: els.authName.value.trim() } : { email, password };
        finishAuth(await api(reg ? '/auth/register' : '/auth/login', { method: 'POST', body }));
    } catch (err) {
        setAuthError('Нет связи с сервером. Проверьте, что бэкенд запущен');
    } finally {
        auth.busy = false;
        els.authSubmit.disabled = false;
    }
}

async function onGoogleCredential(response) {
    setAuthError('');
    try {
        finishAuth(await api('/auth/google', { method: 'POST', body: { credential: response.credential } }));
    } catch (err) {
        setAuthError('Нет связи с сервером. Проверьте, что бэкенд запущен');
    }
}

function initGoogle(clientId) {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.onload = () => {
        if (!window.google || !google.accounts || !google.accounts.id) return;
        google.accounts.id.initialize({ client_id: clientId, callback: onGoogleCredential });
        google.accounts.id.renderButton(els.googleBtn, {
            theme: 'outline', size: 'large', text: 'continue_with', locale: 'ru', width: 320
        });
        els.googleBlock.classList.remove('hidden');
    };
    document.head.appendChild(script);
}

async function bootAuth() {
    auth.token = readToken();
    try {
        const config = await api('/auth/config');
        if (config.ok && config.data.google_client_id) initGoogle(config.data.google_client_id);
        if (!auth.token) return showAuth('');
        const me = await api('/auth/me');
        if (me.ok) return onLoggedIn(me.data);
        auth.token = null;
        saveToken(null);
        showAuth(me.status === 401 ? '' : errorText(me));
    } catch (err) {
        showAuth('Нет связи с сервером. Проверьте, что бэкенд запущен');
    }
}

const pinIcon = (type, label) => L.divIcon({
    className: '',
    html: `<div class="pin ${type}"><span>${label}</span></div>`,
    iconSize: [30, 30],
    iconAnchor: [4, 30]
});

const fmtCoord = ll => `${ll.lat.toFixed(5)}, ${ll.lng.toFixed(5)}`;

function fmtDist(m) {
    return m < 1000 ? `${Math.round(m)} м` : `${(m / 1000).toFixed(2)} км`;
}

function fmtTime(m) {
    const min = Math.max(1, Math.round(m / 1000 / WALK_SPEED_KMH * 60));
    if (min < 60) return `${min} мин`;
    return `${Math.floor(min / 60)} ч ${min % 60} мин`;
}

function routeLength(coords) {
    let total = 0;
    for (let i = 1; i < coords.length; i++) {
        total += map.distance(coords[i - 1], coords[i]);
    }
    return total;
}

function setStatus(text, isError = false) {
    els.status.textContent = text;
    els.status.classList.toggle('error', isError);
}

function updateSteps() {
    const { a, b } = state.markers;
    els.coordA.textContent = a ? fmtCoord(a.getLatLng()) : 'не выбран';
    els.coordB.textContent = b ? fmtCoord(b.getLatLng()) : 'не выбран';
    els.stepA.classList.toggle('done', !!a);
    els.stepB.classList.toggle('done', !!b);
    els.stepA.classList.toggle('active', !a);
    els.stepB.classList.toggle('active', !!a && !b);
    els.swap.disabled = !(a && b);
}

function clearRoute() {
    if (state.controller) state.controller.abort();
    if (state.route) map.removeLayer(state.route);
    state.route = null;
    els.summary.classList.remove('show');
    els.fit.disabled = true;
}

function addMarker(type, latlng) {
    const marker = L.marker(latlng, {
        draggable: true,
        icon: pinIcon(type, type === 'a' ? 'A' : 'B')
    }).addTo(map);
    marker.on('drag', updateSteps);
    marker.on('dragend', () => {
        updateSteps();
        buildRoute();
    });
    state.markers[type] = marker;
    updateSteps();
}

async function buildRoute() {
    const { a, b } = state.markers;
    if (!a || !b) return;
    clearRoute();
    const s = a.getLatLng();
    const e = b.getLatLng();
    state.controller = new AbortController();
    document.body.classList.add('loading');
    setStatus('Строим маршрут...');
    try {
        const res = await api(`/route?lat1=${s.lat}&lon1=${s.lng}&lat2=${e.lat}&lon2=${e.lng}`, {
            signal: state.controller.signal
        });
        if (res.status === 401) {
            logout('Сессия истекла, войдите снова');
            return;
        }
        const data = res.data || {};
        if (data.error) {
            setStatus(data.error + '. Попробуйте передвинуть точки', true);
            return;
        }
        state.route = L.polyline(data.route, { color: '#2563eb', weight: 6, opacity: .9 }).addTo(map);
        const len = routeLength(data.route);
        els.dist.textContent = fmtDist(len);
        els.time.textContent = fmtTime(len);
        els.summary.classList.add('show');
        els.fit.disabled = false;
        setStatus('Маршрут построен. Точки можно перетаскивать');
        map.fitBounds(state.route.getBounds(), { padding: [60, 60] });
    } catch (err) {
        if (err.name === 'AbortError') return;
        setStatus('Нет связи с сервером. Проверьте, что бэкенд запущен', true);
    } finally {
        document.body.classList.remove('loading');
    }
}

function placePoint(latlng) {
    if (!state.markers.a) {
        addMarker('a', latlng);
        setStatus('Теперь поставьте финиш');
    } else if (!state.markers.b) {
        addMarker('b', latlng);
        buildRoute();
    }
}

function resetAll() {
    clearRoute();
    Object.keys(state.markers).forEach(k => {
        if (state.markers[k]) map.removeLayer(state.markers[k]);
        state.markers[k] = null;
    });
    updateSteps();
    setStatus('Кликните на карте, чтобы поставить старт');
    document.body.classList.remove('loading');
}

map.on('click', e => placePoint(e.latlng));

els.reset.addEventListener('click', resetAll);

els.authForm.addEventListener('submit', submitAuth);
els.tabLogin.addEventListener('click', () => setAuthMode('login'));
els.tabRegister.addEventListener('click', () => setAuthMode('register'));
els.logout.addEventListener('click', () => logout(''));

els.fit.addEventListener('click', () => {
    if (state.route) map.fitBounds(state.route.getBounds(), { padding: [60, 60] });
});

els.swap.addEventListener('click', () => {
    const { a, b } = state.markers;
    if (!a || !b) return;
    const pa = a.getLatLng();
    a.setLatLng(b.getLatLng());
    b.setLatLng(pa);
    updateSteps();
    buildRoute();
});

els.locate.addEventListener('click', () => {
    if (!navigator.geolocation) {
        setStatus('Геолокация не поддерживается', true);
        return;
    }
    setStatus('Определяем местоположение...');
    navigator.geolocation.getCurrentPosition(
        pos => {
            const ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
            map.setView(ll, 16);
            placePoint(ll);
        },
        () => setStatus('Не удалось определить местоположение', true),
        { enableHighAccuracy: true, timeout: 10000 }
    );
});

updateSteps();
bootAuth();